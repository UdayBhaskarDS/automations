# import os
# from langchain_openai import OpenAIEmbeddings
# from langchain_text_splitters import RecursiveCharacterTextSplitter
# from langchain_chroma import Chroma
# from langchain.schema import Document
# import numpy as np
# import os
# from dotenv import load_dotenv
# from openai import OpenAI

# # Load variables from .env
# load_dotenv()

# # Embedding model
# embeddings = OpenAIEmbeddings(model="text-embedding-3-small",api_key="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")

# # Initialize Chroma DB (persistent)
# CHROMA_PATH = "chroma_store"
# vectorstore = Chroma(
#     persist_directory=CHROMA_PATH,
#     embedding_function=embeddings
# )

# # Text splitter for chunking
# splitter = RecursiveCharacterTextSplitter(
#     chunk_size=100,
#     chunk_overlap=50
# )

# def cosine_similarity(vec1, vec2):
#     """Cosine similarity between two vectors."""
#     return np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))

# def check_duplicate(file_path, threshold=0.90):
#     """Check if document is duplicate, if not store in vector DB."""
#     with open(file_path, "r") as f:
#         text = f.read()

#     # Chunk document
#     chunks = splitter.split_text(text)
#     documents = [Document(page_content=chunk, metadata={"source": file_path}) for chunk in chunks]

#     # Embed chunks
#     new_embeddings = embeddings.embed_documents([d.page_content for d in documents])

#     # If DB empty, store directly
#     existing_docs = vectorstore.get()
#     if not existing_docs["ids"]:
#         vectorstore.add_documents(documents)
#         vectorstore.persist()
#         print(f"✅ Stored {file_path} (first document, no comparison).")
#         return

#     # Compare against all existing embeddings
#     existing_embeddings = embeddings.embed_documents(existing_docs["documents"])
#     max_similarity = 0
#     for new_vec in new_embeddings:
#         for old_vec in existing_embeddings:
#             sim = cosine_similarity(new_vec, old_vec)
#             max_similarity = max(max_similarity, sim)

#     if max_similarity >= threshold:
#         print(f"❌ {file_path} is a DUPLICATE (max similarity: {max_similarity:.2f}). Not storing.")
#     else:
#         vectorstore.add_documents(documents)
#         vectorstore.persist()
#         print(f"✅ Stored {file_path} (max similarity: {max_similarity:.2f}).")

# if __name__ == "__main__":
#     while True:
#         file_path = input("Enter PRD file path (or 'exit' to quit): ")
#         if file_path.lower() == "exit":
#             break
#         if not os.path.exists(file_path):
#             print("File not found. Try again.")
#             continue
#         check_duplicate(file_path)

import os
import numpy as np
from dotenv import load_dotenv
from langchain_openai import OpenAIEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain.schema import Document

# Load API key
load_dotenv()
embeddings = OpenAIEmbeddings(model="text-embedding-3-small")

# Persistent Chroma DB
CHROMA_PATH = "chroma_store"
vectorstore = Chroma(
    persist_directory=CHROMA_PATH,
    embedding_function=embeddings
)

# Text splitter for chunking
splitter = RecursiveCharacterTextSplitter(
    chunk_size=300,
    chunk_overlap=50
)

def cosine_similarity(vec1, vec2):
    """Cosine similarity between two vectors."""
    return np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))

# def check_duplicate(file_path, sim_threshold=0.90, coverage_threshold=0.7):
#     """Check if document is duplicate, if not store in vector DB."""
#     with open(file_path, "r", encoding="utf-8") as f:
#         text = f.read()

#     # Chunk new document
#     chunks = splitter.split_text(text)
#     documents = [Document(page_content=chunk, metadata={"source": file_path}) for chunk in chunks]

#     # Embed new chunks
#     new_embeddings = embeddings.embed_documents([d.page_content for d in documents])

#     # Fetch existing docs + embeddings from Chroma
#     existing = vectorstore.get(include=["embeddings", "metadatas", "documents"])

#     # If DB empty → store directly
#     if not existing["ids"]:
#         vectorstore.add_documents(documents)
#         vectorstore.persist()
#         print(f"✅ Stored {file_path} (first document, no comparison).")
#         return

#     # Compare against ALL existing embeddings
#     existing_embeddings = np.array(existing["embeddings"])
#     similarities = []

#     for new_vec in new_embeddings:
#         sims = [cosine_similarity(new_vec, old_vec) for old_vec in existing_embeddings]
#         similarities.append(max(sims))  # best match for this chunk

#     # Compute metrics
#     max_similarity = max(similarities)
#     coverage = sum(s >= sim_threshold for s in similarities) / len(similarities)

#     if max_similarity >= sim_threshold and coverage >= coverage_threshold:
#         print(f"❌ {file_path} is a DUPLICATE "
#               f"(max sim: {max_similarity:.2f}, coverage: {coverage:.2f}). Not storing.")
#     else:
#         vectorstore.add_documents(documents)
#         vectorstore.persist()
#         print(f"✅ Stored {file_path} "
#               f"(max sim: {max_similarity:.2f}, coverage: {coverage:.2f}).")
# def check_duplicate(new_doc_chunks, existing_chunks, threshold=0.8):
#     similarities = []

#     for new_chunk in new_doc_chunks:
#         for existing_chunk in existing_chunks:
#             sim = cosine_similarity(new_chunk, existing_chunk)
#             similarities.append(sim)

#     max_similarity = max(similarities) if similarities else 0.0

#     # ✅ Count how many chunks from new_doc are >= threshold
#     overlapping_chunks = sum(1 for sim in similarities if sim >= threshold)
#     coverage = overlapping_chunks / len(new_doc_chunks) if new_doc_chunks else 0.0

#     return max_similarity, coverage
import numpy as np
from langchain_core.documents import Document
from sklearn.metrics.pairwise import cosine_similarity

def check_duplicate(file_path, sim_threshold=0.85, coverage_threshold=0.4):
    """
    Check if a document is a duplicate based on vector similarity.
    If not a duplicate, store in the vector DB.
    
    Args:
        file_path (str): Path to the file to check.
        sim_threshold (float): Similarity threshold (0–1).
        coverage_threshold (float): Proportion of chunks above sim_threshold.
    """
    # Load file
    with open(file_path, "r", encoding="utf-8") as f:
        text = f.read()

    # Split into chunks
    chunks = splitter.split_text(text)
    documents = [Document(page_content=chunk, metadata={"source": file_path}) for chunk in chunks]

    # Embed new chunks
    new_embeddings = embeddings.embed_documents([d.page_content for d in documents])

    # Fetch existing docs + embeddings from Chroma
    existing = vectorstore.get(include=["embeddings", "metadatas", "documents"])

    # If DB empty → store directly
    if not existing["ids"]:
        vectorstore.add_documents(documents)
        vectorstore.persist()
        print(f"✅ Stored {file_path} (first document, no comparison).")
        return

    # Existing embeddings
    existing_embeddings = np.array(existing["embeddings"])

    similarities = []
    for new_vec in new_embeddings:
        sims = cosine_similarity([new_vec], existing_embeddings)[0]
        similarities.append(max(sims))  # best match for this chunk

    # Metrics
    max_similarity = max(similarities)
    avg_similarity = float(np.mean(similarities))
    coverage = sum(s >= sim_threshold for s in similarities) / len(similarities)

    # Decision
    if (max_similarity >= 0.85 and coverage >= 0.3) or (avg_similarity >= sim_threshold and coverage >= coverage_threshold):
        print(f"❌ {file_path} is a DUPLICATE "
              f"(max: {max_similarity:.2f}, avg: {avg_similarity:.2f}, coverage: {coverage:.2f}). Not storing.")
    else:
        vectorstore.add_documents(documents)
        vectorstore.persist()
        print(f"✅ Stored {file_path} "
              f"(max: {max_similarity:.2f}, avg: {avg_similarity:.2f}, coverage: {coverage:.2f}).")


if __name__ == "__main__":
    while True:
        file_path = input("Enter PRD file path (or 'exit' to quit): ")
        if file_path.lower() == "exit":
            break
        if not os.path.exists(file_path):
            print("File not found. Try again.")
            continue
        check_duplicate(file_path)

